import re
import os
import sqlite3
from aiogram import Bot, Dispatcher, types
from aiogram import executor
from dotenv import load_dotenv
from openai import OpenAI
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
import requests
import docx
import PyPDF2
import win32com.client as win32
from templates import *

# Загрузка переменных окружения
load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
BASE_URL = os.getenv('BASE_URL')
API_KEY = os.getenv('API_KEY')

# Инициализация бота, диспетчера и хранилища состояний
bot = Bot(token=TELEGRAM_BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

# Определяем состояния
# Определяем состояния
class ContractStates(StatesGroup):
    waiting_for_contract_id = State()  # Ожидание ввода ID или номера договора
    waiting_for_changes = State()  # Ожидание изменений пользователя
    fz_44_point = State()  # Пункт ФЗ-44
    reason_for_change = State()  # Причина изменения
    point_for_change = State()  # Пункт договора для изменения
    changed_paragraph = State()  # Новая формулировка пункта
    goods_name = State()  # Название товара
    country_of_origin = State()  # Страна производства
    characteristics = State()  # Характеристики товара
    quantity = State()  # Количество товара
    price_per_unit = State()  # Цена за единицу товара
    total_price = State()  # Общая цена
    contract_price_in_words = State()  # Цена в словах
    customer_new_details = State()  # Новые реквизиты заказчика
    executor_new_details = State()  # Новые реквизиты исполнителя

# Инициализация клиента OpenAI
client = OpenAI(base_url=BASE_URL, api_key=API_KEY)

db_file = "ХахатонBD.db"  # Файл базы данных SQLite

# Подключение к базе данных
def get_contract_data(contract_identifier):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT ContractID, Link, ContractNumber, Type FROM Contracts
        WHERE ContractID = ? OR ContractNumber = ?
    """, (contract_identifier, contract_identifier))
    result = cursor.fetchone()
    conn.close()
    return result

# Начало диалога
@dp.message_handler(commands=['start'], state='*')
async def send_welcome(message: types.Message, state: FSMContext):
    await message.reply("Введите ID документа или номер договора, который хотите изменить")
    await ContractStates.waiting_for_contract_id.set()

choice = ''

# Обработка поиска договора
@dp.message_handler(state=ContractStates.waiting_for_contract_id)
async def handle_contract_search(message: types.Message, state: FSMContext):
    contract_identifier = message.text.strip()
    contract_data = get_contract_data(contract_identifier)
    
    if contract_data is None:
        await message.reply("Договор с таким ID или номером не найден.")
        return
    
    contract_id, link, contract_number, file_type = contract_data
    
    # Скачиваем документ по ссылке
    try:
        response = requests.get(link)
        if response.status_code == 200:
            file_name = f"contract_{contract_id}{file_type}"
            with open(file_name, 'wb') as f:
                f.write(response.content)
            await state.update_data(file_name=file_name)
        else:
            await message.reply(f"Ошибка при скачивании файла: {response.status_code}")
            return
    except Exception as e:
        await message.reply(f"Ошибка при скачивании файла: {e}")
        return

    await message.reply("Документ найден. Какие изменения вы хотите внести?(Введите номер) 1 - изменение пункта договора/контракта; 2 - изменение сметы/товара; 3 - измнение реквизитов")
    await ContractStates.waiting_for_changes.set()

# Извлечение текста из документов
def extract_text_from_file(file_name):
    text = ""
    if file_name.endswith('.doc'):
        word = win32.Dispatch("Word.Application")
        doc = word.Documents.Open(os.path.abspath(file_name))
        text = doc.Content.Text
        doc.Close(False)
        word.Quit()
    elif file_name.endswith('.docx'):
        doc = docx.Document(file_name)
        text = "\n".join([paragraph.text for paragraph in doc.paragraphs])
    elif file_name.endswith('.pdf'):
        with open(file_name, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text += page.extract_text()
    return text

variables = {
            'contract_year': '',
            'contract_number': '',
            'customer_company_name': '',
            'customer_representative_info': '',
            'customer_authority_document': '',
            'executor_company_name': '',
            'executor_alias': '',
            'executor_representative_info': '',
            'executor_authority_document': '',
            'customer_representative_name': '',
            'executor_representative_name': '',
            'point_change': '',
            'goods_change': '',
            'details_change': ''
        }

@dp.message_handler(state=ContractStates.waiting_for_changes)
async def handle_changes(message: types.Message, state: FSMContext):
    changes = message.text.strip()
    data = await state.get_data()
    file_name = data.get("file_name")

    try:
        # Извлекаем текст из документа
        document_text = extract_text_from_file(file_name)

        # Формируем промт и отправляем его в LLM
        dialog_history = [
    {"role": "system", "content": "Вы помощник, который извлекает информацию из текста договора. В зависимости от запроса пользователя, пометьте тип изменений, которые нужно внести, и запросите недостающие переменные, если они необходимы. Используйте следующие метки: #point_change, #goods_change, #details_change. Формат ответа: только значения для каждой из указанных переменных или метка типа изменения."},
    {"role": "user", "content": f"""
Текст документа:
{document_text}

Что нужно извлечь из документа:
#contract_year – год заключения договора/контракта (уже существующего)
#contract_number – номер договора/контракта (уже существующего)
#customer_company_name – название компании заказчика (может быть индивидуальный предприниматель)
#customer_representative_info – информация о представителе компании заказчика (может быть должность и ФИО), надо взять текст, идущий после 'в лице', далее менять формы слова и падежи не надо! ('в лице' включать не надо!), надо должность и имя!
#customer_authority_document – документ, на основании которого действует заказчик (вся информация про этот документ, т. е. название документа, номер, и всё, что к этому документу относится), надо взять текст, идущий после 'действующего на основании', далее менять формы слова и падежи не надо!
#executor_company_name – название компании исполнителя (может быть индивидуальный предприниматель), если индивидуальный предприниматель то так и надо написать
#executor_alias – как будет в дальнейшем именоваться заказчик (может быть исполнитель, поставщик и др.)
#executor_representative_info – информация о представителе компании исполнителя/поставщика (может быть должность и ФИО), надо взять текст, идущий после 'в лице', далее менять формы слова и падежи не надо ('в лице' включать не надо!), надо должность и имя!
#executor_authority_document – документ, на основании которого действует исполнитель/поставщик (вся информация про этот документ, т. е. название документа, номер, и всё, что к этому документу относится), надо взять текст, идущий после 'действующего на основании', далее менять формы слова и падежи не надо!
#customer_representative_name – ФИО представителя компании заказчика обязательно в именительном падеже!
#executor_representative_name – ФИО представителя компании исполнителя/поставщика обязательно в именительном падеже!
#old_price - старая цена товара

Что именно нужно изменить в документе:
#point_change – Если требуется изменить пункт договора. В этом случае, укажите пункт, причину изменения, номер пункта и новую формулировку.
#goods_change – Если требуется изменить информацию о товарах. В этом случае, укажите название товара, страну производства, характеристики, количество, цену за единицу, общую цену и цену в словах.
#details_change – Если требуется изменить реквизиты заказчика или исполнителя. Укажите новые реквизиты.

Пожалуйста, включите метку типа изменения в свой ответ и распознайте, что именно должно быть изменено в документе (point_change, goods_change или details_change. Это нужно написать именно в таком виде! point_change - если изенение пункта договора, goods_change - если изменение информации о товарах, details_change - если изменение реквизитов поставщика или заказчика)."""
    }
]

        response = client.chat.completions.create(
            model="llama3:8b",  # Замените на вашу модель
            messages=dialog_history
        )

        response_content = response.choices[0].message.content

        # Распарсить метки и переменные из ответа
        variables = {
            'contract_year': re.search(r'#contract_year\s*-\s*(.*)', response_content),
            'contract_number': re.search(r'#contract_number\s*-\s*(.*)', response_content),
            'customer_company_name': re.search(r'#customer_company_name\s*-\s*(.*)', response_content),
            'customer_representative_info': re.search(r'#customer_representative_info\s*-\s*(.*)', response_content),
            'customer_authority_document': re.search(r'#customer_authority_document\s*-\s*(.*)', response_content),
            'executor_company_name': re.search(r'#executor_company_name\s*-\s*(.*)', response_content),
            'executor_alias': re.search(r'#executor_alias\s*-\s*(.*)', response_content),
            'executor_representative_info': re.search(r'#executor_representative_info\s*-\s*(.*)', response_content),
            'executor_authority_document': re.search(r'#executor_authority_document\s*-\s*(.*)', response_content),
            'customer_representative_name': re.search(r'#customer_representative_name\s*-\s*(.*)', response_content),
            'executor_representative_name': re.search(r'#executor_representative_name\s*-\s*(.*)', response_content),
            'old_price': re.search(r'#old_price\s*-\s*(.*)', response_content),
        }

        # Определение типа изменения
        change_type = re.search(r'#(point_change|goods_change|details_change)', response_content)

        # Очистка значений, если ничего не найдено
        for key, match in variables.items():
            if match:
                variables[key] = match.group(1).strip()
            else:
                variables[key] = None
        
        await message.reply(f"Распарсенные данные:\n{variables}")

        # Сохранить распарсенные значения в состояние
        async with state.proxy() as data:
            data.update(variables)

        choice = message.text.strip()

        # Определение типа изменения
        if choice != '':
            if choice == '1':
                await message.reply("Введите пункт договора, в котором написано, что все изменения могут быть только по ФЗ-44:")
                await ContractStates.fz_44_point.set()
            elif choice == '2':
                await message.reply("Введите название товара:")
                await ContractStates.goods_name.set()
        
            elif choice == '3':
                await message.reply("Введите новые реквизиты заказчика:")
                await ContractStates.customer_new_details.set()
        else:
            await message.reply("Не удалось определить тип изменения. Пожалуйста, уточните.")
            await state.finish()

        # if '#point_change' in response_content:
        #     await message.reply("Введите пункт договора, в котором написано, что все изменения могут быть только по ФЗ-44:")
        #     await ContractStates.fz_44_point.set()

        # elif '#goods_change' in response_content:
        #     await message.reply("Введите название товара:")
        #     await ContractStates.goods_name.set()

        # elif '#details_change' in response_content:
        #     await message.reply("Введите новые реквизиты заказчика:")
        #     await ContractStates.customer_new_details.set()

        # else:
        #     await message.reply("Не удалось определить тип изменения. Пожалуйста, уточните.")
        #     await state.finish()

    except Exception as e:
        await message.reply(f"Ошибка при обработке файла: {e}")
        return

    # await state.finish()  # Завершаем состояние
@dp.message_handler(state=ContractStates.point_for_change)
async def process_point_for_change(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['point_for_change'] = message.text
        await message.reply("Введите новую формулировку пункта:")
        await ContractStates.changed_paragraph.set()

@dp.message_handler(state=ContractStates.changed_paragraph)
async def process_changed_paragraph(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['changed_paragraph'] = message.text
        # Вызов функции изменения пункта
        point_change(
            variables['contract_year'],
            variables['contract_number'],
            variables['customer_company_name'],
            variables['customer_representative_info'],
            variables['customer_authority_document'],
            variables['executor_company_name'],
            variables['executor_alias'],
            variables['executor_representative_info'],
            variables['executor_authority_document'],
            data.get('fz_44_point'),
            data.get('reason_for_change'),
            data.get('point_for_change'),
            data.get('changed_paragraph'),
            variables['customer_representative_name'],
            variables['executor_representative_name']
        )
        # Сохранение и отправка изменённого документа
        ## НЕ ЗАБЫТЬ
        await message.reply("Документ с изменениями сохранен. Отправляю в чат...")
        with open("Дополнительное соглашение .docx", "rb") as doc_file:
            await message.answer_document(doc_file)
        await state.finish()

@dp.message_handler(state=ContractStates.goods_name)
async def process_goods_name(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['goods_name'] = message.text
        await message.reply("Введите страну производства товара:")
        await ContractStates.country_of_origin.set()

@dp.message_handler(state=ContractStates.country_of_origin)
async def process_country_of_origin(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['country_of_origin'] = message.text
        await message.reply("Введите характеристики товара:")
        await ContractStates.characteristics.set()

@dp.message_handler(state=ContractStates.characteristics)
async def process_characteristics(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['characteristics'] = message.text
        await message.reply("Введите количество товара:")
        await ContractStates.quantity.set()

@dp.message_handler(state=ContractStates.quantity)
async def process_quantity(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['quantity'] = message.text
        await message.reply("Введите цену за единицу товара:")
        await ContractStates.price_per_unit.set()
        

@dp.message_handler(state=ContractStates.price_per_unit)
async def process_price_per_unit(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['price_per_unit'] = message.text
        while True :
            await message.reply("Введите общую цену за все товары:")
            await ContractStates.total_price.set()
            if variables['old_price'] == None:
                break
            if int(message.text.strip()) > int(variables['old_price']) * 1.1:
                True
            else:
                False


@dp.message_handler(state=ContractStates.total_price)
async def process_total_price(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['total_price'] = message.text
        await message.reply("Введите цену за все товары (буквами):")
        await ContractStates.contract_price_in_words.set()

@dp.message_handler(state=ContractStates.contract_price_in_words)
async def process_contract_price_in_words(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['contract_price_in_words'] = message.text
        # Вызов функции изменения товаров
        goods_change(
            variables['contract_year'],
            variables['contract_number'],
            variables['customer_company_name'],
            variables['customer_representative_info'],
            variables['customer_authority_document'],
            variables['executor_company_name'],
            variables['executor_alias'],
            variables['executor_representative_info'],
            variables['executor_authority_document'],
            data.get('goods_name'),
            data.get('country_of_origin'),
            data.get('characteristics'),
            data.get('quantity'),
            data.get('price_per_unit'),
            data.get('total_price'),
            data.get('contract_price_in_words'),
            variables['customer_representative_name'],
            variables['executor_representative_name']
        )
        # Сохранение и отправка изменённого документа
        await message.reply("Документ с изменениями сохранен. Отправляю в чат...")
        with open("Дополнительное соглашение .docx", "rb") as doc_file:
            await message.answer_document(doc_file)
        await state.finish()

@dp.message_handler(state=ContractStates.customer_new_details)
async def process_customer_new_details(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['customer_new_details'] = message.text
        await message.reply("Введите новые реквизиты исполнителя:")
        await ContractStates.executor_new_details.set()

@dp.message_handler(state=ContractStates.executor_new_details)
async def process_executor_new_details(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['executor_new_details'] = message.text
        # Вызов функции изменения реквизитов
        details_change(
            variables['contract_year'],
            variables['contract_number'],
            variables['customer_company_name'],
            variables['customer_representative_info'],
            variables['customer_authority_document'],
            variables['executor_company_name'],
            variables['executor_alias'],
            variables['executor_representative_info'],
            variables['executor_authority_document'],
            data.get('customer_new_details'),
            data.get('executor_new_details'),
            variables['customer_representative_name'],
            variables['executor_representative_name']
        )
        # Сохранение и отправка изменённого документа
        await message.reply("Документ с изменениями сохранен. Отправляю в чат...")
        with open("Дополнительное соглашение .docx", "rb") as doc_file:
            await message.answer_document(doc_file)
        await state.finish()
if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)