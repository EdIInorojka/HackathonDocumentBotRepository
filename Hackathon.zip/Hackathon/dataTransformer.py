import sqlite3

# Загрузка данных из Excel
excel_file = 'data.xlsx'
df = pd.read_excel(excel_file)

# Добавление уникального ID к данным
df['id'] = range(1, len(df) + 1)

# Подключение к базе данных (или создание новой базы)
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Создание таблицы, если она не существует
cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY,
        name TEXT,
        price REAL,
        expiration_date TEXT
    )
''')

# Загрузка данных в базу
for _, row in df.iterrows():
    cursor.execute('''
        INSERT INTO products (id, name, price, expiration_date)
        VALUES (?, ?, ?, ?)
    ''', (row['id'], row['name'], row['price'], row['expiration_date']))

# Сохранение изменений
conn.commit()
conn.close()