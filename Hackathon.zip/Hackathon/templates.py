from docxtpl import DocxTemplate
import datetime

months = {1: 'Января', 2: 'Февраля', 3: 'Марта', 4: 'Апреля', 5: 'Мая', 6: 'Июня',
          7: 'Июля', 8: 'Августа', 9: 'Сентября', 10: 'Октября', 11: 'Ноября', 12: 'Декабря'}

def point_change(contract_year, contract_number, customer_company_name, customer_representative_info,
                 customer_authority_document, executor_company_name, executor_alias, executor_representative_info, executor_authority_document,
                 fz_44_point, reason_for_change, point_for_change, changed_paragraph, customer_representative_name, executor_representative_name):
    # contract_day – день заключения договора/контракта (уже сущетвующего)
    # contract_month – месяц заключения договор/контракта (уже сущетвующего)
    # contract_year – год заключения договора/контракта (уже сущетвующего)
    # contract_number – номер договора/контракта (уже сущетвующего)
    # customer_company_name – название компании заказчика (может быть индивидульный предприниматель)
    # customer_representative_info – информация о представителе компании заказчика (может быть должность и ФИО), надо взять текст, идущий после 'в лице', далее менять формы слова и падежи не надо! ('в лице' включать не надо!), надо должность и имя!
    # customer_authority_document – документ, на основании которого действует заказчик (вся информация про этот документ, т. е. название документа, номер, и всё, что к этому документу относится), надо взять текст, идущий после 'действующего на основании', далее менять формы слова и падежи не надо!
    # executor_company_name – название компании исполнителя (может быть индивидульный предприниматель), если индивидульный предприниматель то так и надо написать
    # executor_alias – как будет в дальнейшем именоваться заказчик (может быть исполнитель, поставщик и др.)
    # executor_representative_info – информация о представителе компании исполннителя/поставщика (может быть должность и ФИО), надо взять текст, идущий после 'в лице', далее менять формы слова и падежи не надо ('в лице' включать не надо!), надо должность и имя!
    # executor_authority_document – документ, на основании которого действует исполннитель/поставщик (вся информация про этот документ, т. е. название документа, номер, и всё, что к этому документу относится), надо взять текст, идущий после 'действующего на основании', далее менять формы слова и падежи не надо!
    # -------point_change------(Вводится пользователем)
    # fz_44_point – пункт догвоора, в котором написано, что все изменения дговора/контракта могут быть только по фезеральному закону № 44-ФЗ
    # reason_for_change – причина изменения пункта (передается пользователем через чат)
    # point_for_change – номер пункта, в котором просходит изменение
    # changed_paragraph – новая формулировка пункта, в котором просходит изменение
    # -------goods_change------(Вводится пользователем)
    # goods_name – название товара
    # country_of_origin – страна производства товара
    # characteristics – характеристика товара
    # quantity – количество товара
    # price_per_unit – цена за единицу товара
    # total_price – цена за все товары
    # contract_price_in_words – цена за все товары (буквами)
    # -------goods_change------(Вводится пользователем)
    # customer_new_details – новые реквизиты заказчика
    # executor_new_details – новые реквизиты исполнителя
    # customer_representative_name – ФИО представителя компании заказчика обязательно в именительном падеже!
    # executor_representative_name – ФИО представителя компании исполннителя/поставщика обязательно в именительном падеже!

    customer_representative_name = [i for i in customer_representative_name.split(' ')]
    executor_representative_name = [i for i in executor_representative_name.split(' ')]
    
    context = { 'contract_year': contract_year,
                'contract_number': contract_number,
                'current_day': datetime.datetime.now().day,
                'current_month': months[datetime.datetime.now().month],
                'current_year': datetime.datetime.now().year,
                'customer_company_name': customer_company_name,
                'customer_representative_info': customer_representative_info,
                'customer_authority_document': customer_authority_document,
                'executor_company_name': executor_company_name,
                'executor_alias': executor_alias,
                'executor_representative_info': executor_representative_info,
                'executor_authority_document': executor_authority_document,
                'fz_44_point': fz_44_point,
                'reason_for_change': reason_for_change,
                'point_for_change': point_for_change,
                'changed_paragraph': changed_paragraph,
                # 'customer_representative_name': f'{customer_representative_name[1][0]}.{customer_representative_name[0][0]}. {customer_representative_name[2]}',
                # 'executor_representative_name': f'{executor_representative_name[1][0]}.{executor_representative_name[0][0]}. {executor_representative_name[2]}',
                'customer_representative_name': customer_representative_name,
                'executor_representative_name': executor_representative_name,
                'point_change': True,
                'goods_change': False,
                'details_change': False
                }
    
    doc = DocxTemplate("Шаблон ДС изменене пункта.docx")
    doc.render(context)
    doc.save("Дополнительное соглашение .docx")

# point_change('*не указано*', '*не указано*', '*не указано*', '33', 'Управа района Филевский парк города Москвы', 'главы управы Мирошниченко Романа Евгеньевича', 
#              'Положения «Об управе района города Москвы», утвержденного постановлением Правительства Москвы от 24 февраля 2010 г. № 157-ПП «О полномочиях территориальных органов исполнительной власти города Москвы»', 
#              'Индивидуальный предприниматель Швец Татьяна Николаевна', 'Поставщик', 'Швец Татьяны Николаевны',
#              'Свидетельства № 310774631600746', '11.5', 'ПРИЧИНА ПОЛЬЗОВАТЕЛЯ', '12.5', '*Измененнный параграф*', 'Мирошниченко Роман Евгеньевич', 'Швец Татьяна Николаевна')

def goods_change(contract_year, contract_number, customer_company_name, customer_representative_info,
                 customer_authority_document, executor_company_name, executor_alias, executor_representative_info, executor_authority_document,
                 goods_name, country_of_origin, characteristics, quantity, price_per_unit, total_price, contract_price_in_words,
                 customer_representative_name, executor_representative_name):
    
    customer_representative_name = [i for i in customer_representative_name.split(' ')]
    executor_representative_name = [i for i in executor_representative_name.split(' ')]

    context = { 'contract_year': contract_year,
                'contract_number': contract_number,
                'current_day': datetime.datetime.now().day,
                'current_month': months[datetime.datetime.now().month],
                'current_year': datetime.datetime.now().year,
                'customer_company_name': customer_company_name,
                'customer_representative_info': customer_representative_info,
                'customer_authority_document': customer_authority_document,
                'executor_company_name': executor_company_name,
                'executor_alias': executor_alias,
                'executor_representative_info': executor_representative_info,
                'executor_authority_document': executor_authority_document,
                'goods_name': goods_name,
                'country_of_origin': country_of_origin,
                'characteristics': characteristics,
                'quantity': quantity,
                'price_per_unit': price_per_unit,
                'total_price': total_price,
                'contract_price_in_words': contract_price_in_words,
                # 'customer_representative_name': f'{customer_representative_name[1][0]}.{customer_representative_name[0][0]}. {customer_representative_name[2]}',
                # 'executor_representative_name': f'{executor_representative_name[1][0]}.{executor_representative_name[0][0]}. {executor_representative_name[2]}',
                'customer_representative_name': customer_representative_name,
                'executor_representative_name': executor_representative_name,
                'point_change': False,
                'goods_change': True,
                'details_change': False
                }
    
    doc = DocxTemplate("Шаблон ДС изменене пункта.docx")
    doc.render(context)
    doc.save("Дополнительное соглашение .docx")

# goods_change('*не указано*', '*не указано*', '*не указано*', '33', 'Управа района Филевский парк города Москвы', 'главы управы Мирошниченко Романа Евгеньевича', 
#              'Положения «Об управе района города Москвы», утвержденного постановлением Правительства Москвы от 24 февраля 2010 г. № 157-ПП «О полномочиях территориальных органов исполнительной власти города Москвы»', 
#              'Индивидуальный предприниматель Швец Татьяна Николаевна', 'Поставщик', 'Швец Татьяны Николаевны',
#              'Свидетельства № 310774631600746', 'Имя товара', 'Китай', 'Лютая Характеристика', '3', '2000', '6000', 'шесть тысяч рублей',
#              'Мирошниченко Роман Евгеньевич', 'Швец Татьяна Николаевна')

def details_change(contract_year, contract_number, customer_company_name, customer_representative_info,
                 customer_authority_document, executor_company_name, executor_alias, executor_representative_info, executor_authority_document,
                 customer_new_details, executor_new_details, customer_representative_name, executor_representative_name):

    customer_representative_name = [i for i in customer_representative_name.split(' ')]
    executor_representative_name = [i for i in executor_representative_name.split(' ')]

    context = { 'contract_year': contract_year,
                'contract_number': contract_number,
                'current_day': datetime.datetime.now().day,
                'current_month': months[datetime.datetime.now().month],
                'current_year': datetime.datetime.now().year,
                'customer_company_name': customer_company_name,
                'customer_representative_info': customer_representative_info,
                'customer_authority_document': customer_authority_document,
                'executor_company_name': executor_company_name,
                'executor_alias': executor_alias,
                'executor_representative_info': executor_representative_info,
                'executor_authority_document': executor_authority_document,
                'customer_new_details': customer_new_details,
                'executor_new_details': executor_new_details,
                # # 'customer_representative_name': f'{customer_representative_name[1][0]}.{customer_representative_name[0][0]}. {customer_representative_name[2]}',
                # 'executor_representative_name': f'{executor_representative_name[1][0]}.{executor_representative_name[0][0]}. {executor_representative_name[2]}',
                'customer_representative_name': customer_representative_name,
                'executor_representative_name': executor_representative_name,
                'point_change': False,
                'goods_change': False,
                'details_change': True
                }
    
    doc = DocxTemplate("Шаблон ДС изменене пункта.docx")
    doc.render(context)
    doc.save("Дополнительное соглашение .docx")

# details_change('*не указано*', '*не указано*', '*не указано*', '33', 'Управа района Филевский парк города Москвы', 'главы управы Мирошниченко Романа Евгеньевича', 
#                 'Положения «Об управе района города Москвы», утвержденного постановлением Правительства Москвы от 24 февраля 2010 г. № 157-ПП «О полномочиях территориальных органов исполнительной власти города Москвы»', 
#                 'Индивидуальный предприниматель Швец Татьяна Николаевна', 'Поставщик', 'Швец Татьяны Николаевны',
#                 'Свидетельства № 310774631600746', 'НОВЫЕ РЕКВИЗИТЫ ЗАКАЗЧИКА', 'НОВЫЕ РЕКВИЗИТЫ ИСПОЛНИТЕЛЯ',
#                 'Мирошниченко Роман Евгеньевич', 'Швец Татьяна Николаевна')